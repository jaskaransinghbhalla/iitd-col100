from binascii import a2b_base64


a1=float(input())
a2=float(input())
a3=float(input())
a4=float(input())
a5=float(input())
a6=float(input())
a7=float(input())
a8=float(input())
a9=float(input())
print(3.14*a1*a1)
print(a2*a2)
print(a3*a4)
print(a5*a6)
print(0.5*(a7+a8)*a9)