def addition(a,b):
    print(a+b)
def subtraction(a,b):
    k=a-b
    print(a-b)