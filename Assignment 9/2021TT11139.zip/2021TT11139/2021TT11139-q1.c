#include <stdio.h>

int main(){
    int a =100 ,b = 200 ,c;
    c = a*b;

    if (b!=0){
        printf("%d\n", c);
    }else{
        int d = 0;
        printf("%d\n",d);
    }
    return 0;
}